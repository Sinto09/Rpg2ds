RPG 2DS - Atelier de blocs personnalisés

Ajout :
- 8 emplacements de blocs personnalisés.
- Atelier pixel art 16x16 au stylet sur l'écran tactile.
- 8 couleurs, dont la première case sert de gomme.
- Propriété solide / traversable (touche Y).
- Sauvegarde des blocs dans sdmc:/3ds/rpg2ds/blocks.bin.
- Les blocs personnalisés sont disponibles dans la palette de l'éditeur de carte.

Utilisation :
1. Ouvrir Éditeurs > Blocs / textures.
2. L/R pour choisir un emplacement.
3. Dessiner sur la grille avec le stylet.
4. Choisir une couleur en touchant une case de la palette en bas.
5. Y pour alterner solide / traversable.
6. X pour enregistrer le bloc, A pour enregistrer et revenir.
7. Dans l'éditeur de carte, faire défiler les tuiles avec L/R jusqu'au bloc personnalisé.

Compilation :
Compiler avec l'environnement devkitARM / libctru / citro2d du projet.
La compilation n'a pas pu être exécutée dans cet environnement car devkitARM n'est pas installé ici.
